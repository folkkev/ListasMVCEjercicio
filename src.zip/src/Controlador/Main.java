package Controlador;
import Vista.*;
import Modelo.*;
public class Main {
    public static void main (String[] args) {

        // elegir  lista
        //panel de opciones con switch case




    }
}