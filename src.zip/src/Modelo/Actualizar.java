package Modelo;

public class Actualizar {
    public void modificarDato(int[] numeros, int posicion, int nuevoValor) {
        numeros [posicion] = nuevoValor;

    }
}
