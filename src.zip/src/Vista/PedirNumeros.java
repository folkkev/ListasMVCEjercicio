package Vista;
import java.util.Scanner;
public class PedirNumeros {
    private Scanner PedirNumero = new Scanner(System.in);

        public int[] pedir10Numeros() {
            int[] ListaNumeros = new int[10];
            System.out.println("Digite 10 números");
            for (int i = 0; i < 10; i++) {
                System.out.print("\nDigite el número " + (i + 1) + ": ");
                ListaNumeros[i] = PedirNumero.nextInt();
            }
            return ListaNumeros;
        }

        public int pedirNumero(String mensaje) {                   //se usa para pedir cosas como el indice o la opcion
            System.out.print(mensaje);
            return PedirNumero.nextInt();
        }

        public int pedirNuevoValor() {                                  //lo podria cambiar a uno solo con el de arribas
            System.out.print("Digite el nuevo número: ");
            return PedirNumero.nextInt();
        }
 }
