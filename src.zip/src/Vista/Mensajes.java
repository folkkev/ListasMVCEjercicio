package Vista;

public class Mensajes {
    public void ImprimirMensajes(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarLista(int[] numeros) {
        System.out.println("Lista Actual");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println( (i+1) + ") : " + numeros[i]);
        }
    }
}
